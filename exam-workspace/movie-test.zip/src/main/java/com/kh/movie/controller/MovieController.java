package com.kh.movie.controller;

public class MovieController {

}
