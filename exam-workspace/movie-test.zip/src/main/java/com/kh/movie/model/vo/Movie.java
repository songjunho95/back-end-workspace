package com.kh.movie.model.vo;

public class Movie {
	
}
