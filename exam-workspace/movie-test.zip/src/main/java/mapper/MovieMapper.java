package mapper;

public interface MovieMapper {

}